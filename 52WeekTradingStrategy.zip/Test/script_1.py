# Install required packages
import subprocess
import sys

# Install yfinance
subprocess.check_call([sys.executable, "-m", "pip", "install", "yfinance"])
print("yfinance installed successfully!")