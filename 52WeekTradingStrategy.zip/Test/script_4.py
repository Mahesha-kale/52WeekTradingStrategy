def backtest_strategy(strategy, num_backtests=100):
    """
    Backtest the strategy multiple times to get win/loss statistics
    """
    print("\n" + "="*60)
    print("BACKTESTING STRATEGY")
    print("="*60)
    print(f"Running {num_backtests} backtest simulations...")
    
    all_trades = []
    
    for backtest_run in range(num_backtests):
        if (backtest_run + 1) % 20 == 0:
            print(f"Completed {backtest_run + 1}/{num_backtests} backtests...")
        
        # Generate a portfolio of stocks for this backtest
        portfolio_trades = []
        
        # Test each stock in our universe
        for symbol in strategy.indian_stocks[:15]:  # Test subset for efficiency
            # Generate historical data for backtesting
            data, market_cap = strategy.generate_stock_data(symbol, days=365)
            
            # Check if stock qualifies for entry
            if market_cap < 1000:
                continue
            
            # Simulate entry at different time periods
            for entry_day in range(50, len(data) - 60, 30):  # Entry points every 30 days
                entry_data = data.iloc[:entry_day + 1]
                future_data = data.iloc[entry_day:]
                
                if len(future_data) < 30:  # Need at least 30 days of future data
                    continue
                
                current_price = entry_data['Close'].iloc[-1]
                week_52_high, week_52_low, midpoint = strategy.calculate_52_week_range(entry_data)
                
                # Check entry criteria
                criterion_1 = strategy.check_first_half_criterion(current_price, week_52_high, week_52_low)
                criterion_2 = strategy.check_monthly_candle_criterion(entry_data, current_price)
                criterion_3 = strategy.check_weekly_candle_criterion(entry_data)
                
                if not (criterion_1 and criterion_2 and criterion_3):
                    continue
                
                # Calculate position size
                stop_loss = week_52_low
                target_price = week_52_high
                quantity, risk_amount, profit_potential, risk_reward_ratio = strategy.calculate_position_size(
                    current_price, stop_loss, target_price
                )
                
                if quantity <= 0:
                    continue
                
                # Simulate the trade outcome
                entry_price = current_price
                trade_outcome = simulate_trade_outcome(future_data, entry_price, stop_loss, target_price)
                
                trade = {
                    'symbol': symbol,
                    'entry_price': entry_price,
                    'stop_loss': stop_loss,
                    'target_price': target_price,
                    'quantity': quantity,
                    'risk_amount': risk_amount,
                    'profit_potential': profit_potential,
                    'outcome': trade_outcome['outcome'],
                    'exit_price': trade_outcome['exit_price'],
                    'days_held': trade_outcome['days_held'],
                    'actual_pnl': trade_outcome['actual_pnl'],
                    'backtest_run': backtest_run
                }
                
                portfolio_trades.append(trade)
        
        all_trades.extend(portfolio_trades)
    
    return analyze_backtest_results(all_trades)

def simulate_trade_outcome(future_data, entry_price, stop_loss, target_price):
    """
    Simulate what happens to a trade over time
    """
    for i, (date, row) in enumerate(future_data.iterrows()):
        # Check if stop loss hit
        if row['Low'] <= stop_loss:
            return {
                'outcome': 'LOSS',
                'exit_price': stop_loss,
                'days_held': i + 1,
                'actual_pnl': stop_loss - entry_price
            }
        
        # Check if target hit
        if row['High'] >= target_price:
            return {
                'outcome': 'WIN',
                'exit_price': target_price,
                'days_held': i + 1,
                'actual_pnl': target_price - entry_price
            }
    
    # If neither target nor stop loss hit, exit at last price
    final_price = future_data['Close'].iloc[-1]
    outcome = 'WIN' if final_price > entry_price else 'LOSS'
    
    return {
        'outcome': outcome,
        'exit_price': final_price,
        'days_held': len(future_data),
        'actual_pnl': final_price - entry_price
    }

def analyze_backtest_results(all_trades):
    """
    Analyze backtest results and calculate statistics
    """
    if not all_trades:
        print("No trades generated in backtest!")
        return
    
    df_trades = pd.DataFrame(all_trades)
    
    # Calculate key statistics
    total_trades = len(all_trades)
    winning_trades = len(df_trades[df_trades['outcome'] == 'WIN'])
    losing_trades = len(df_trades[df_trades['outcome'] == 'LOSS'])
    
    win_rate = (winning_trades / total_trades) * 100
    
    # P&L Statistics
    total_pnl = df_trades['actual_pnl'].sum()
    avg_win = df_trades[df_trades['outcome'] == 'WIN']['actual_pnl'].mean() if winning_trades > 0 else 0
    avg_loss = df_trades[df_trades['outcome'] == 'LOSS']['actual_pnl'].mean() if losing_trades > 0 else 0
    
    # Risk-adjusted returns
    total_risk_amount = df_trades['risk_amount'].sum()
    risk_adjusted_return = (total_pnl / total_risk_amount * 100) if total_risk_amount > 0 else 0
    
    # Average holding period
    avg_holding_days = df_trades['days_held'].mean()
    
    print("\n" + "="*60)
    print("BACKTEST RESULTS & PERFORMANCE ANALYSIS")
    print("="*60)
    
    print(f"Total Trades Executed: {total_trades:,}")
    print(f"Winning Trades: {winning_trades:,}")
    print(f"Losing Trades: {losing_trades:,}")
    print(f"Win Rate: {win_rate:.1f}%")
    print(f"")
    print(f"Average Winning Trade: ₹{avg_win:.2f}")
    print(f"Average Losing Trade: ₹{avg_loss:.2f}")
    print(f"Average Holding Period: {avg_holding_days:.1f} days")
    print(f"")
    print(f"Total P&L: ₹{total_pnl:.2f}")
    print(f"Risk-Adjusted Return: {risk_adjusted_return:.2f}%")
    
    # Strategy Assessment
    print(f"\n" + "="*60)
    print("STRATEGY ASSESSMENT")
    print("="*60)
    
    if win_rate > 51:
        print(f"✅ SUCCESS: Win rate of {win_rate:.1f}% exceeds the 51% threshold!")
        print("✅ Strategy shows positive edge and is potentially profitable")
    else:
        print(f"❌ FAILURE: Win rate of {win_rate:.1f}% is below the 51% threshold")
        print("❌ Strategy needs optimization or may not be viable")
    
    if risk_adjusted_return > 0:
        print(f"✅ Positive risk-adjusted return of {risk_adjusted_return:.2f}%")
    else:
        print(f"❌ Negative risk-adjusted return of {risk_adjusted_return:.2f}%")
    
    # Top performing symbols
    symbol_performance = df_trades.groupby('symbol').agg({
        'outcome': lambda x: (x == 'WIN').sum() / len(x) * 100,
        'actual_pnl': 'sum'
    }).round(2)
    
    symbol_performance.columns = ['Win_Rate_%', 'Total_PnL']
    symbol_performance = symbol_performance.sort_values('Total_PnL', ascending=False)
    
    print(f"\n" + "="*40)
    print("TOP 10 PERFORMING STOCKS")
    print("="*40)
    print(symbol_performance.head(10).to_string())
    
    return {
        'total_trades': total_trades,
        'win_rate': win_rate,
        'total_pnl': total_pnl,
        'risk_adjusted_return': risk_adjusted_return,
        'avg_holding_days': avg_holding_days,
        'trades_df': df_trades
    }

# Run backtest
backtest_results = backtest_strategy(strategy, num_backtests=50)