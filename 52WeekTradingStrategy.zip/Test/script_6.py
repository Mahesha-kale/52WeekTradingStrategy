# Create the complete Python code file
complete_code = '''"""
Indian Stock Trading Strategy
============================

This script implements a comprehensive stock trading strategy for Indian markets with the following features:
1. Market cap screening (>1000 crores)
2. 52-week range analysis (first half criterion)
3. Monthly candle analysis (75%-100% range)
4. Weekly candle momentum check
5. Position sizing with risk management
6. Backtesting functionality
7. Win/loss percentage analysis

Strategy Rules:
- Entry: Current price when all criteria are met
- Stop Loss: 52-week low
- Target: 52-week high
- Risk per trade: Max 2% of portfolio
- Position size: Max 10% of portfolio per trade
- Risk:Reward ratio must be > 1:1

Author: AI Trading Strategy Generator
Date: October 2024
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random

class IndianStockStrategy:
    def __init__(self, portfolio_capital=10000):
        """
        Initialize the strategy with portfolio capital
        
        Args:
            portfolio_capital (float): Total portfolio capital in INR
        """
        self.portfolio_capital = portfolio_capital
        self.max_risk_per_trade = 0.02  # 2%
        self.max_position_size = 0.10   # 10%
        self.max_risk_amount = self.portfolio_capital * self.max_risk_per_trade
        self.max_position_amount = self.portfolio_capital * self.max_position_size
        
        # Sample Indian stocks for simulation
        # In real implementation, use actual NSE symbols with .NS suffix
        self.indian_stocks = [
            'RELIANCE', 'TCS', 'INFY', 'HDFCBANK', 'ICICIBANK',
            'HINDUNILVR', 'SBIN', 'BHARTIARTL', 'ITC', 'KOTAKBANK',
            'LT', 'ASIANPAINT', 'MARUTI', 'HCLTECH', 'WIPRO',
            'TITAN', 'ULTRACEMCO', 'ONGC', 'TATASTEEL', 'ADANIPORTS',
            'POWERGRID', 'NESTLEIND', 'BAJFINANCE', 'BAJAJFINSV',
            'TECHM', 'SUNPHARMA', 'DRREDDY', 'CIPLA', 'DIVISLAB',
            'COALINDIA', 'NTPC', 'JSWSTEEL', 'TATAMOTORS', 'M&M'
        ]
        
        self._setup_random_seed()
        self._display_strategy_info()
    
    def _setup_random_seed(self):
        """Set random seed for reproducible results"""
        np.random.seed(42)
        random.seed(42)
    
    def _display_strategy_info(self):
        """Display strategy initialization information"""
        print("=== INDIAN STOCK SCREENING STRATEGY ===")
        print(f"Portfolio Capital: ₹{self.portfolio_capital:,}")
        print(f"Max Risk per Trade: 2% (₹{self.max_risk_amount:,})")
        print(f"Max Position Size: 10% (₹{self.max_position_amount:,})")
    
    def generate_stock_data(self, symbol, days=365):
        """
        Generate realistic stock data for simulation
        In real implementation, replace this with actual data fetching from APIs like yfinance
        
        Args:
            symbol (str): Stock symbol
            days (int): Number of days of data to generate
            
        Returns:
            tuple: (DataFrame with OHLCV data, market cap in crores)
        """
        # Generate base price between 50-2000
        base_price = random.uniform(50, 2000)
        
        # Generate market cap (some > 1000 crores, some < 1000 crores)
        market_cap = random.uniform(500, 50000)  # in crores
        
        dates = pd.date_range(end=datetime.now(), periods=days, freq='D')
        
        # Generate price series with some volatility
        returns = np.random.normal(0.0005, 0.02, days)  # Daily returns
        prices = [base_price]
        
        for i in range(1, days):
            new_price = prices[i-1] * (1 + returns[i])
            prices.append(max(new_price, base_price * 0.3))  # Floor at 30% of base
        
        # Create OHLCV data
        data = []
        for i, price in enumerate(prices):
            noise = random.uniform(0.98, 1.02)
            high = price * random.uniform(1.0, 1.05)
            low = price * random.uniform(0.95, 1.0)
            open_price = price * noise
            close_price = price
            volume = random.randint(100000, 10000000)
            
            data.append({
                'Date': dates[i],
                'Open': open_price,
                'High': high,
                'Low': low,
                'Close': close_price,
                'Volume': volume
            })
        
        df = pd.DataFrame(data)
        df.set_index('Date', inplace=True)
        
        return df, market_cap
    
    def calculate_52_week_range(self, data):
        """
        Calculate 52-week high and low
        
        Args:
            data (DataFrame): Stock price data
            
        Returns:
            tuple: (52-week high, 52-week low, midpoint)
        """
        week_52_high = data['High'].max()
        week_52_low = data['Low'].min()
        midpoint = (week_52_high + week_52_low) / 2
        return week_52_high, week_52_low, midpoint
    
    def check_first_half_criterion(self, current_price, week_52_high, week_52_low):
        """
        Check if current price is in first half of 52-week range
        
        Args:
            current_price (float): Current stock price
            week_52_high (float): 52-week high
            week_52_low (float): 52-week low
            
        Returns:
            bool: True if price is in first half of range
        """
        midpoint = (week_52_high + week_52_low) / 2
        return week_52_low <= current_price <= midpoint
    
    def check_monthly_candle_criterion(self, data, current_price):
        """
        Check if price lies in 75%-100% of current month candle range
        
        Args:
            data (DataFrame): Stock price data
            current_price (float): Current stock price
            
        Returns:
            bool: True if price is in 75%-100% range of monthly candle
        """
        # Get last 30 days data
        monthly_data = data.tail(30)
        if len(monthly_data) == 0:
            return False
        
        monthly_high = monthly_data['High'].max()
        monthly_low = monthly_data['Low'].min()
        range_75_percent = monthly_low + 0.75 * (monthly_high - monthly_low)
        
        return range_75_percent <= current_price <= monthly_high
    
    def check_weekly_candle_criterion(self, data):
        """
        Check if weekly candle is green or has more buying than previous week
        
        Args:
            data (DataFrame): Stock price data
            
        Returns:
            bool: True if weekly criteria is met
        """
        # Get weekly data
        weekly_data = data.resample('W').agg({
            'Open': 'first',
            'High': 'max',
            'Low': 'min',
            'Close': 'last',
            'Volume': 'sum'
        }).dropna()
        
        if len(weekly_data) < 2:
            return False
        
        current_week = weekly_data.iloc[-1]
        previous_week = weekly_data.iloc[-2]
        
        # Check if current week is green
        is_green = current_week['Close'] > current_week['Open']
        
        # Check if current week has higher high than previous week
        higher_high = current_week['High'] > previous_week['High']
        
        return is_green or higher_high
    
    def calculate_position_size(self, current_price, stop_loss, target_price):
        """
        Calculate position size based on risk management rules
        
        Args:
            current_price (float): Current stock price
            stop_loss (float): Stop loss price
            target_price (float): Target price
            
        Returns:
            tuple: (quantity, risk_amount, profit_potential, risk_reward_ratio)
        """
        # Calculate risk per share
        risk_per_share = current_price - stop_loss
        
        if risk_per_share <= 0:
            return 0, 0, 0, 0  # Invalid setup
        
        # Calculate reward per share
        reward_per_share = target_price - current_price
        
        # Check risk-reward ratio (should be > 1:1)
        risk_reward_ratio = reward_per_share / risk_per_share if risk_per_share > 0 else 0
        if risk_reward_ratio <= 1:
            return 0, 0, 0, 0  # Risk-reward not favorable
        
        # Calculate max quantity based on risk limit (2% rule)
        max_qty_risk = int(self.max_risk_amount / risk_per_share)
        
        # Calculate max quantity based on position size limit (10% rule)
        max_qty_position = int(self.max_position_amount / current_price)
        
        # Take minimum of both constraints
        quantity = min(max_qty_risk, max_qty_position)
        
        if quantity <= 0:
            return 0, 0, 0, 0
        
        # Calculate actual risk and potential profit
        actual_risk = quantity * risk_per_share
        potential_profit = quantity * reward_per_share
        
        return quantity, actual_risk, potential_profit, risk_reward_ratio
    
    def screen_stock(self, symbol):
        """
        Screen a single stock based on all criteria
        
        Args:
            symbol (str): Stock symbol to screen
            
        Returns:
            dict or None: Stock details if qualified, None otherwise
        """
        # Generate stock data and market cap
        data, market_cap = self.generate_stock_data(symbol)
        
        # Check market cap criterion
        if market_cap < 1000:  # Less than 1000 crores
            return None
        
        current_price = data['Close'].iloc[-1]
        week_52_high, week_52_low, midpoint = self.calculate_52_week_range(data)
        
        # Check all criteria
        criterion_1 = self.check_first_half_criterion(current_price, week_52_high, week_52_low)
        criterion_2 = self.check_monthly_candle_criterion(data, current_price)
        criterion_3 = self.check_weekly_candle_criterion(data)
        
        # All criteria must be met
        if not (criterion_1 and criterion_2 and criterion_3):
            return None
        
        # Calculate position sizing
        stop_loss = week_52_low
        target_price = week_52_high
        quantity, risk_amount, profit_potential, risk_reward_ratio = self.calculate_position_size(
            current_price, stop_loss, target_price
        )
        
        if quantity <= 0:
            return None
        
        return {
            'symbol': symbol,
            'current_price': round(current_price, 2),
            'entry_price': round(current_price, 2),
            'stop_loss': round(stop_loss, 2),
            'target_price': round(target_price, 2),
            'quantity': quantity,
            'risk_amount': round(risk_amount, 2),
            'profit_potential': round(profit_potential, 2),
            'risk_reward_ratio': round(risk_reward_ratio, 2),
            'market_cap': round(market_cap, 2),
            '52_week_high': round(week_52_high, 2),
            '52_week_low': round(week_52_low, 2),
            'position_value': round(current_price * quantity, 2),
            'data': data  # Store for backtesting
        }
    
    def screen_all_stocks(self):
        """
        Screen all stocks and return qualifying ones
        
        Returns:
            list: List of qualified stocks
        """
        qualified_stocks = []
        
        print("\\n" + "="*50)
        print("STOCK SCREENING PROCESS")
        print("="*50)
        
        for i, symbol in enumerate(self.indian_stocks):
            print(f"Processing {symbol} ({i+1}/{len(self.indian_stocks)})")
            result = self.screen_stock(symbol)
            if result:
                qualified_stocks.append(result)
                print(f"  ✓ QUALIFIED: {symbol}")
            else:
                print(f"  ✗ Not qualified")
        
        return qualified_stocks

def display_qualified_stocks(qualified_stocks):
    """
    Display qualified stocks in a formatted table
    
    Args:
        qualified_stocks (list): List of qualified stocks
    """
    if not qualified_stocks:
        print("\\nNo stocks qualified based on the criteria!")
        return
    
    print("\\n" + "="*80)
    print("QUALIFIED STOCKS - ENTRY SIGNALS")
    print("="*80)
    
    # Create DataFrame for better display
    df_data = []
    for stock in qualified_stocks:
        df_data.append({
            'Symbol': stock['symbol'],
            'Entry Price': f"₹{stock['entry_price']:.2f}",
            'Stop Loss': f"₹{stock['stop_loss']:.2f}",
            'Target': f"₹{stock['target_price']:.2f}",
            'Quantity': stock['quantity'],
            'Position Value': f"₹{stock['position_value']:.2f}",
            'Risk Amount': f"₹{stock['risk_amount']:.2f}",
            'Profit Potential': f"₹{stock['profit_potential']:.2f}",
            'R:R Ratio': f"{stock['risk_reward_ratio']:.2f}",
            'Market Cap': f"₹{stock['market_cap']:.0f}Cr"
        })
    
    df = pd.DataFrame(df_data)
    print(df.to_string(index=False))
    
    # Summary statistics
    total_risk = sum([stock['risk_amount'] for stock in qualified_stocks])
    total_profit_potential = sum([stock['profit_potential'] for stock in qualified_stocks])
    total_position_value = sum([stock['position_value'] for stock in qualified_stocks])
    avg_risk_reward = sum([stock['risk_reward_ratio'] for stock in qualified_stocks]) / len(qualified_stocks)
    
    print(f"\\n" + "="*80)
    print("PORTFOLIO SUMMARY")
    print("="*80)
    print(f"Total Qualified Stocks: {len(qualified_stocks)}")
    print(f"Total Position Value: ₹{total_position_value:.2f}")
    print(f"Total Risk Amount: ₹{total_risk:.2f}")
    print(f"Total Profit Potential: ₹{total_profit_potential:.2f}")
    print(f"Average Risk:Reward Ratio: {avg_risk_reward:.2f}")

def simulate_trade_outcome(future_data, entry_price, stop_loss, target_price):
    """
    Simulate what happens to a trade over time
    
    Args:
        future_data (DataFrame): Future price data
        entry_price (float): Entry price
        stop_loss (float): Stop loss price
        target_price (float): Target price
        
    Returns:
        dict: Trade outcome details
    """
    for i, (date, row) in enumerate(future_data.iterrows()):
        # Check if stop loss hit
        if row['Low'] <= stop_loss:
            return {
                'outcome': 'LOSS',
                'exit_price': stop_loss,
                'days_held': i + 1,
                'actual_pnl': stop_loss - entry_price
            }
        
        # Check if target hit
        if row['High'] >= target_price:
            return {
                'outcome': 'WIN',
                'exit_price': target_price,
                'days_held': i + 1,
                'actual_pnl': target_price - entry_price
            }
    
    # If neither target nor stop loss hit, exit at last price
    final_price = future_data['Close'].iloc[-1]
    outcome = 'WIN' if final_price > entry_price else 'LOSS'
    
    return {
        'outcome': outcome,
        'exit_price': final_price,
        'days_held': len(future_data),
        'actual_pnl': final_price - entry_price
    }

def backtest_strategy(strategy, num_backtests=100):
    """
    Backtest the strategy multiple times to get win/loss statistics
    
    Args:
        strategy (IndianStockStrategy): Strategy instance
        num_backtests (int): Number of backtest runs
        
    Returns:
        dict: Backtest results and statistics
    """
    print("\\n" + "="*60)
    print("BACKTESTING STRATEGY")
    print("="*60)
    print(f"Running {num_backtests} backtest simulations...")
    
    all_trades = []
    
    for backtest_run in range(num_backtests):
        if (backtest_run + 1) % 20 == 0:
            print(f"Completed {backtest_run + 1}/{num_backtests} backtests...")
        
        # Generate a portfolio of stocks for this backtest
        portfolio_trades = []
        
        # Test each stock in our universe
        for symbol in strategy.indian_stocks[:15]:  # Test subset for efficiency
            # Generate historical data for backtesting
            data, market_cap = strategy.generate_stock_data(symbol, days=365)
            
            # Check if stock qualifies for entry
            if market_cap < 1000:
                continue
            
            # Simulate entry at different time periods
            for entry_day in range(50, len(data) - 60, 30):  # Entry points every 30 days
                entry_data = data.iloc[:entry_day + 1]
                future_data = data.iloc[entry_day:]
                
                if len(future_data) < 30:  # Need at least 30 days of future data
                    continue
                
                current_price = entry_data['Close'].iloc[-1]
                week_52_high, week_52_low, midpoint = strategy.calculate_52_week_range(entry_data)
                
                # Check entry criteria
                criterion_1 = strategy.check_first_half_criterion(current_price, week_52_high, week_52_low)
                criterion_2 = strategy.check_monthly_candle_criterion(entry_data, current_price)
                criterion_3 = strategy.check_weekly_candle_criterion(entry_data)
                
                if not (criterion_1 and criterion_2 and criterion_3):
                    continue
                
                # Calculate position size
                stop_loss = week_52_low
                target_price = week_52_high
                quantity, risk_amount, profit_potential, risk_reward_ratio = strategy.calculate_position_size(
                    current_price, stop_loss, target_price
                )
                
                if quantity <= 0:
                    continue
                
                # Simulate the trade outcome
                entry_price = current_price
                trade_outcome = simulate_trade_outcome(future_data, entry_price, stop_loss, target_price)
                
                trade = {
                    'symbol': symbol,
                    'entry_price': entry_price,
                    'stop_loss': stop_loss,
                    'target_price': target_price,
                    'quantity': quantity,
                    'risk_amount': risk_amount,
                    'profit_potential': profit_potential,
                    'outcome': trade_outcome['outcome'],
                    'exit_price': trade_outcome['exit_price'],
                    'days_held': trade_outcome['days_held'],
                    'actual_pnl': trade_outcome['actual_pnl'],
                    'backtest_run': backtest_run
                }
                
                portfolio_trades.append(trade)
        
        all_trades.extend(portfolio_trades)
    
    return analyze_backtest_results(all_trades)

def analyze_backtest_results(all_trades):
    """
    Analyze backtest results and calculate statistics
    
    Args:
        all_trades (list): List of all trades from backtesting
        
    Returns:
        dict: Analysis results
    """
    if not all_trades:
        print("No trades generated in backtest!")
        return
    
    df_trades = pd.DataFrame(all_trades)
    
    # Calculate key statistics
    total_trades = len(all_trades)
    winning_trades = len(df_trades[df_trades['outcome'] == 'WIN'])
    losing_trades = len(df_trades[df_trades['outcome'] == 'LOSS'])
    
    win_rate = (winning_trades / total_trades) * 100
    
    # P&L Statistics
    total_pnl = df_trades['actual_pnl'].sum()
    avg_win = df_trades[df_trades['outcome'] == 'WIN']['actual_pnl'].mean() if winning_trades > 0 else 0
    avg_loss = df_trades[df_trades['outcome'] == 'LOSS']['actual_pnl'].mean() if losing_trades > 0 else 0
    
    # Risk-adjusted returns
    total_risk_amount = df_trades['risk_amount'].sum()
    risk_adjusted_return = (total_pnl / total_risk_amount * 100) if total_risk_amount > 0 else 0
    
    # Average holding period
    avg_holding_days = df_trades['days_held'].mean()
    
    print("\\n" + "="*60)
    print("BACKTEST RESULTS & PERFORMANCE ANALYSIS")
    print("="*60)
    
    print(f"Total Trades Executed: {total_trades:,}")
    print(f"Winning Trades: {winning_trades:,}")
    print(f"Losing Trades: {losing_trades:,}")
    print(f"Win Rate: {win_rate:.1f}%")
    print(f"")
    print(f"Average Winning Trade: ₹{avg_win:.2f}")
    print(f"Average Losing Trade: ₹{avg_loss:.2f}")
    print(f"Average Holding Period: {avg_holding_days:.1f} days")
    print(f"")
    print(f"Total P&L: ₹{total_pnl:.2f}")
    print(f"Risk-Adjusted Return: {risk_adjusted_return:.2f}%")
    
    # Strategy Assessment
    print(f"\\n" + "="*60)
    print("STRATEGY ASSESSMENT")
    print("="*60)
    
    if win_rate > 51:
        print(f"✅ SUCCESS: Win rate of {win_rate:.1f}% exceeds the 51% threshold!")
        print("✅ Strategy shows positive edge and is potentially profitable")
    else:
        print(f"❌ FAILURE: Win rate of {win_rate:.1f}% is below the 51% threshold")
        print("❌ Strategy needs optimization or may not be viable")
    
    if risk_adjusted_return > 0:
        print(f"✅ Positive risk-adjusted return of {risk_adjusted_return:.2f}%")
    else:
        print(f"❌ Negative risk-adjusted return of {risk_adjusted_return:.2f}%")
    
    return {
        'total_trades': total_trades,
        'win_rate': win_rate,
        'total_pnl': total_pnl,
        'risk_adjusted_return': risk_adjusted_return,
        'avg_holding_days': avg_holding_days,
        'trades_df': df_trades
    }

def demonstrate_position_sizing_examples(strategy):
    """
    Demonstrate the position sizing examples
    
    Args:
        strategy (IndianStockStrategy): Strategy instance
    """
    print("\\n" + "="*70)
    print("POSITION SIZING EXAMPLES (AS PER SPECIFICATIONS)")
    print("="*70)
    
    # Example 1: Stock worth ₹100, 52-week range 90-120
    print("EXAMPLE 1:")
    print("-" * 50)
    current_price_1 = 100
    week_52_low_1 = 90
    week_52_high_1 = 120
    
    quantity_1, risk_1, profit_1, rr_ratio_1 = strategy.calculate_position_size(
        current_price_1, week_52_low_1, week_52_high_1
    )
    
    print(f"Stock Price: ₹{current_price_1}")
    print(f"52-Week Range: ₹{week_52_low_1} - ₹{week_52_high_1}")
    print(f"Final Quantity: {quantity_1} shares")
    print(f"Position Value: ₹{current_price_1 * quantity_1}")
    print(f"Max Loss: ₹{risk_1}")
    print(f"Max Profit: ₹{profit_1}")
    print(f"Risk:Reward Ratio: {rr_ratio_1:.2f}")
    
    # Example 2: Stock worth ₹500, 52-week range 350-700
    print("\\nEXAMPLE 2:")
    print("-" * 50)
    current_price_2 = 500
    week_52_low_2 = 350
    week_52_high_2 = 700
    
    quantity_2, risk_2, profit_2, rr_ratio_2 = strategy.calculate_position_size(
        current_price_2, week_52_low_2, week_52_high_2
    )
    
    print(f"Stock Price: ₹{current_price_2}")
    print(f"52-Week Range: ₹{week_52_low_2} - ₹{week_52_high_2}")
    print(f"Final Quantity: {quantity_2} shares")
    print(f"Position Value: ₹{current_price_2 * quantity_2}")
    print(f"Max Loss: ₹{risk_2}")
    print(f"Max Profit: ₹{profit_2}")
    print(f"Risk:Reward Ratio: {rr_ratio_2:.2f}")

# Main execution function
def main():
    """
    Main function to execute the complete strategy
    """
    # Initialize strategy with ₹10,000 portfolio
    strategy = IndianStockStrategy(portfolio_capital=10000)
    
    # Screen stocks
    qualified_stocks = strategy.screen_all_stocks()
    display_qualified_stocks(qualified_stocks)
    
    # Demonstrate position sizing examples
    demonstrate_position_sizing_examples(strategy)
    
    # Run backtest
    backtest_results = backtest_strategy(strategy, num_backtests=50)
    
    print("\\n" + "="*60)
    print("STRATEGY EXECUTION COMPLETED")
    print("="*60)
    print("The strategy has been fully executed with:")
    print("1. ✅ Stock screening based on multiple criteria")
    print("2. ✅ Position sizing with risk management")
    print("3. ✅ Backtesting with win/loss analysis")
    print("4. ✅ Performance evaluation")
    
    return strategy, qualified_stocks, backtest_results

if __name__ == "__main__":
    # Execute the complete strategy
    strategy, qualified_stocks, backtest_results = main()
'''

# Save the complete code to a file
with open('indian_stock_strategy.py', 'w') as f:
    f.write(complete_code)

print("\n" + "="*60)
print("COMPLETE PYTHON CODE SAVED")
print("="*60)
print("✅ File saved as: indian_stock_strategy.py")
print("✅ Complete implementation with all features")
print("✅ Ready for execution and further customization")
print("\nTo use the code:")
print("1. Install required packages: pandas, numpy")
print("2. For real data: Install yfinance and replace data generation")
print("3. Run: python indian_stock_strategy.py")
print("4. Customize stock list and parameters as needed")

# Display file size
import os
file_size = os.path.getsize('indian_stock_strategy.py')
print(f"\nFile size: {file_size:,} bytes")
print(f"Lines of code: {len(complete_code.splitlines())} lines")