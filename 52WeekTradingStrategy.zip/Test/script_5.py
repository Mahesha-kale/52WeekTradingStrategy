# Demonstrate the position sizing examples from the user's query

def demonstrate_position_sizing_examples(strategy):
    """
    Demonstrate the position sizing examples provided in the user's query
    """
    print("\n" + "="*70)
    print("POSITION SIZING EXAMPLES (AS PER USER'S SPECIFICATIONS)")
    print("="*70)
    
    # Example 1: Stock worth ₹100, 52-week range 90-120
    print("EXAMPLE 1:")
    print("-" * 50)
    current_price_1 = 100
    week_52_low_1 = 90
    week_52_high_1 = 120
    
    quantity_1, risk_1, profit_1, rr_ratio_1 = strategy.calculate_position_size(
        current_price_1, week_52_low_1, week_52_high_1
    )
    
    print(f"Stock Price: ₹{current_price_1}")
    print(f"52-Week Range: ₹{week_52_low_1} - ₹{week_52_high_1}")
    print(f"Position Size (10% rule): Max ₹{strategy.max_position_amount} / ₹{current_price_1} = {int(strategy.max_position_amount/current_price_1)} shares")
    print(f"Risk per share: ₹{current_price_1 - week_52_low_1}")
    print(f"Max risk allowed (2% rule): ₹{strategy.max_risk_amount}")
    print(f"Max shares by risk rule: {int(strategy.max_risk_amount/(current_price_1 - week_52_low_1))} shares")
    print(f"Final Quantity: {quantity_1} shares (minimum of both rules)")
    print(f"Position Value: ₹{current_price_1 * quantity_1}")
    print(f"Max Loss: ₹{risk_1}")
    print(f"Max Profit: ₹{profit_1}")
    print(f"Risk:Reward Ratio: {rr_ratio_1:.2f}")
    
    print(f"\n")
    
    # Example 2: Stock worth ₹500, 52-week range 350-700
    print("EXAMPLE 2:")
    print("-" * 50)
    current_price_2 = 500
    week_52_low_2 = 350
    week_52_high_2 = 700
    
    quantity_2, risk_2, profit_2, rr_ratio_2 = strategy.calculate_position_size(
        current_price_2, week_52_low_2, week_52_high_2
    )
    
    print(f"Stock Price: ₹{current_price_2}")
    print(f"52-Week Range: ₹{week_52_low_2} - ₹{week_52_high_2}")
    print(f"Position Size (10% rule): Max ₹{strategy.max_position_amount} / ₹{current_price_2} = {int(strategy.max_position_amount/current_price_2)} shares")
    print(f"Risk per share: ₹{current_price_2 - week_52_low_2}")
    print(f"Max risk allowed (2% rule): ₹{strategy.max_risk_amount}")
    print(f"Max shares by risk rule: {int(strategy.max_risk_amount/(current_price_2 - week_52_low_2))} shares")
    print(f"Final Quantity: {quantity_2} shares (minimum of both rules)")
    print(f"Position Value: ₹{current_price_2 * quantity_2}")
    print(f"Max Loss: ₹{risk_2}")
    print(f"Max Profit: ₹{profit_2}")
    print(f"Risk:Reward Ratio: {rr_ratio_2:.2f}")
    
    print(f"\n" + "="*70)
    print("POSITION SIZING VALIDATION")
    print("="*70)
    print(f"Example 1 - 2% Risk Rule Check: ₹{risk_1} ≤ ₹{strategy.max_risk_amount} ✅" if risk_1 <= strategy.max_risk_amount else f"Example 1 - 2% Risk Rule Check: ₹{risk_1} > ₹{strategy.max_risk_amount} ❌")
    print(f"Example 1 - 10% Position Rule Check: ₹{current_price_1 * quantity_1} ≤ ₹{strategy.max_position_amount} ✅" if current_price_1 * quantity_1 <= strategy.max_position_amount else f"Example 1 - 10% Position Rule Check: ₹{current_price_1 * quantity_1} > ₹{strategy.max_position_amount} ❌")
    
    print(f"Example 2 - 2% Risk Rule Check: ₹{risk_2} ≤ ₹{strategy.max_risk_amount} ✅" if risk_2 <= strategy.max_risk_amount else f"Example 2 - 2% Risk Rule Check: ₹{risk_2} > ₹{strategy.max_risk_amount} ❌")
    print(f"Example 2 - 10% Position Rule Check: ₹{current_price_2 * quantity_2} ≤ ₹{strategy.max_position_amount} ✅" if current_price_2 * quantity_2 <= strategy.max_position_amount else f"Example 2 - 10% Position Rule Check: ₹{current_price_2 * quantity_2} > ₹{strategy.max_position_amount} ❌")

demonstrate_position_sizing_examples(strategy)