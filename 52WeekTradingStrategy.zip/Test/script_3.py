def screen_all_stocks(strategy):
    """
    Screen all stocks and return qualifying ones
    """
    qualified_stocks = []
    
    print("\n" + "="*50)
    print("STOCK SCREENING PROCESS")
    print("="*50)
    
    for i, symbol in enumerate(strategy.indian_stocks):
        print(f"Processing {symbol} ({i+1}/{len(strategy.indian_stocks)})")
        result = strategy.screen_stock(symbol)
        if result:
            qualified_stocks.append(result)
            print(f"  ✓ QUALIFIED: {symbol}")
        else:
            print(f"  ✗ Not qualified")
    
    return qualified_stocks

def display_qualified_stocks(qualified_stocks):
    """
    Display qualified stocks in a formatted table
    """
    if not qualified_stocks:
        print("\nNo stocks qualified based on the criteria!")
        return
    
    print("\n" + "="*80)
    print("QUALIFIED STOCKS - ENTRY SIGNALS")
    print("="*80)
    
    # Create DataFrame for better display
    df_data = []
    for stock in qualified_stocks:
        df_data.append({
            'Symbol': stock['symbol'],
            'Entry Price': f"₹{stock['entry_price']:.2f}",
            'Stop Loss': f"₹{stock['stop_loss']:.2f}",
            'Target': f"₹{stock['target_price']:.2f}",
            'Quantity': stock['quantity'],
            'Position Value': f"₹{stock['position_value']:.2f}",
            'Risk Amount': f"₹{stock['risk_amount']:.2f}",
            'Profit Potential': f"₹{stock['profit_potential']:.2f}",
            'R:R Ratio': f"{stock['risk_reward_ratio']:.2f}",
            'Market Cap': f"₹{stock['market_cap']:.0f}Cr"
        })
    
    df = pd.DataFrame(df_data)
    print(df.to_string(index=False))
    
    # Summary statistics
    total_risk = sum([stock['risk_amount'] for stock in qualified_stocks])
    total_profit_potential = sum([stock['profit_potential'] for stock in qualified_stocks])
    total_position_value = sum([stock['position_value'] for stock in qualified_stocks])
    avg_risk_reward = sum([stock['risk_reward_ratio'] for stock in qualified_stocks]) / len(qualified_stocks)
    
    print(f"\n" + "="*80)
    print("PORTFOLIO SUMMARY")
    print("="*80)
    print(f"Total Qualified Stocks: {len(qualified_stocks)}")
    print(f"Total Position Value: ₹{total_position_value:.2f}")
    print(f"Total Risk Amount: ₹{total_risk:.2f} ({(total_risk/10000)*100:.1f}% of portfolio)")
    print(f"Total Profit Potential: ₹{total_profit_potential:.2f}")
    print(f"Average Risk:Reward Ratio: {avg_risk_reward:.2f}")
    print(f"Portfolio Risk Utilization: {(total_risk/200)*100:.1f}% of maximum allowed risk")

# Run the screening process
qualified_stocks = screen_all_stocks(strategy)
display_qualified_stocks(qualified_stocks)