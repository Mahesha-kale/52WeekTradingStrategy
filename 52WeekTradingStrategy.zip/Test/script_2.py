import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random

# Set random seed for reproducible results
np.random.seed(42)
random.seed(42)

class IndianStockStrategy:
    def __init__(self, portfolio_capital=10000):
        """
        Initialize the strategy with portfolio capital
        """
        self.portfolio_capital = portfolio_capital
        self.max_risk_per_trade = 0.02  # 2%
        self.max_position_size = 0.10   # 10%
        self.max_risk_amount = self.portfolio_capital * self.max_risk_per_trade
        self.max_position_amount = self.portfolio_capital * self.max_position_size
        
        # Sample Indian stocks for simulation
        self.indian_stocks = [
            'RELIANCE', 'TCS', 'INFY', 'HDFCBANK', 'ICICIBANK',
            'HINDUNILVR', 'SBIN', 'BHARTIARTL', 'ITC', 'KOTAKBANK',
            'LT', 'ASIANPAINT', 'MARUTI', 'HCLTECH', 'WIPRO',
            'TITAN', 'ULTRACEMCO', 'ONGC', 'TATASTEEL', 'ADANIPORTS',
            'POWERGRID', 'NESTLEIND', 'BAJFINANCE', 'BAJAJFINSV',
            'TECHM', 'SUNPHARMA', 'DRREDDY', 'CIPLA', 'DIVISLAB',
            'COALINDIA', 'NTPC', 'JSWSTEEL', 'TATAMOTORS', 'M&M'
        ]
        
        print("=== INDIAN STOCK SCREENING STRATEGY ===")
        print(f"Portfolio Capital: ₹{self.portfolio_capital:,}")
        print(f"Max Risk per Trade: 2% (₹{self.max_risk_amount:,})")
        print(f"Max Position Size: 10% (₹{self.max_position_amount:,})")
    
    def generate_stock_data(self, symbol, days=365):
        """
        Generate realistic stock data for simulation
        """
        # Generate base price between 50-2000
        base_price = random.uniform(50, 2000)
        
        # Generate market cap (some > 1000 crores, some < 1000 crores)
        market_cap = random.uniform(500, 50000)  # in crores
        
        dates = pd.date_range(end=datetime.now(), periods=days, freq='D')
        
        # Generate price series with some volatility
        returns = np.random.normal(0.0005, 0.02, days)  # Daily returns
        prices = [base_price]
        
        for i in range(1, days):
            new_price = prices[i-1] * (1 + returns[i])
            prices.append(max(new_price, base_price * 0.3))  # Floor at 30% of base
        
        # Create OHLCV data
        data = []
        for i, price in enumerate(prices):
            noise = random.uniform(0.98, 1.02)
            high = price * random.uniform(1.0, 1.05)
            low = price * random.uniform(0.95, 1.0)
            open_price = price * noise
            close_price = price
            volume = random.randint(100000, 10000000)
            
            data.append({
                'Date': dates[i],
                'Open': open_price,
                'High': high,
                'Low': low,
                'Close': close_price,
                'Volume': volume
            })
        
        df = pd.DataFrame(data)
        df.set_index('Date', inplace=True)
        
        return df, market_cap
    
    def calculate_52_week_range(self, data):
        """
        Calculate 52-week high and low
        """
        week_52_high = data['High'].max()
        week_52_low = data['Low'].min()
        midpoint = (week_52_high + week_52_low) / 2
        return week_52_high, week_52_low, midpoint
    
    def check_first_half_criterion(self, current_price, week_52_high, week_52_low):
        """
        Check if current price is in first half of 52-week range
        """
        midpoint = (week_52_high + week_52_low) / 2
        return week_52_low <= current_price <= midpoint
    
    def check_monthly_candle_criterion(self, data, current_price):
        """
        Check if price lies in 75%-100% of current month candle range
        """
        # Get last 30 days data
        monthly_data = data.tail(30)
        if len(monthly_data) == 0:
            return False
        
        monthly_high = monthly_data['High'].max()
        monthly_low = monthly_data['Low'].min()
        range_75_percent = monthly_low + 0.75 * (monthly_high - monthly_low)
        
        return range_75_percent <= current_price <= monthly_high
    
    def check_weekly_candle_criterion(self, data):
        """
        Check if weekly candle is green or has more buying than previous week
        """
        # Get weekly data
        weekly_data = data.resample('W').agg({
            'Open': 'first',
            'High': 'max',
            'Low': 'min',
            'Close': 'last',
            'Volume': 'sum'
        }).dropna()
        
        if len(weekly_data) < 2:
            return False
        
        current_week = weekly_data.iloc[-1]
        previous_week = weekly_data.iloc[-2]
        
        # Check if current week is green
        is_green = current_week['Close'] > current_week['Open']
        
        # Check if current week has higher high than previous week
        higher_high = current_week['High'] > previous_week['High']
        
        return is_green or higher_high
    
    def calculate_position_size(self, current_price, stop_loss, target_price):
        """
        Calculate position size based on risk management rules
        """
        # Calculate risk per share
        risk_per_share = current_price - stop_loss
        
        if risk_per_share <= 0:
            return 0, 0, 0, 0  # Invalid setup
        
        # Calculate reward per share
        reward_per_share = target_price - current_price
        
        # Check risk-reward ratio (should be > 1:1)
        risk_reward_ratio = reward_per_share / risk_per_share if risk_per_share > 0 else 0
        if risk_reward_ratio <= 1:
            return 0, 0, 0, 0  # Risk-reward not favorable
        
        # Calculate max quantity based on risk limit (2% rule)
        max_qty_risk = int(self.max_risk_amount / risk_per_share)
        
        # Calculate max quantity based on position size limit (10% rule)
        max_qty_position = int(self.max_position_amount / current_price)
        
        # Take minimum of both constraints
        quantity = min(max_qty_risk, max_qty_position)
        
        if quantity <= 0:
            return 0, 0, 0, 0
        
        # Calculate actual risk and potential profit
        actual_risk = quantity * risk_per_share
        potential_profit = quantity * reward_per_share
        
        return quantity, actual_risk, potential_profit, risk_reward_ratio
    
    def screen_stock(self, symbol):
        """
        Screen a single stock based on all criteria
        """
        # Generate stock data and market cap
        data, market_cap = self.generate_stock_data(symbol)
        
        # Check market cap criterion
        if market_cap < 1000:  # Less than 1000 crores
            return None
        
        current_price = data['Close'].iloc[-1]
        week_52_high, week_52_low, midpoint = self.calculate_52_week_range(data)
        
        # Check all criteria
        criterion_1 = self.check_first_half_criterion(current_price, week_52_high, week_52_low)
        criterion_2 = self.check_monthly_candle_criterion(data, current_price)
        criterion_3 = self.check_weekly_candle_criterion(data)
        
        # All criteria must be met
        if not (criterion_1 and criterion_2 and criterion_3):
            return None
        
        # Calculate position sizing
        stop_loss = week_52_low
        target_price = week_52_high
        quantity, risk_amount, profit_potential, risk_reward_ratio = self.calculate_position_size(
            current_price, stop_loss, target_price
        )
        
        if quantity <= 0:
            return None
        
        return {
            'symbol': symbol,
            'current_price': round(current_price, 2),
            'entry_price': round(current_price, 2),
            'stop_loss': round(stop_loss, 2),
            'target_price': round(target_price, 2),
            'quantity': quantity,
            'risk_amount': round(risk_amount, 2),
            'profit_potential': round(profit_potential, 2),
            'risk_reward_ratio': round(risk_reward_ratio, 2),
            'market_cap': round(market_cap, 2),
            '52_week_high': round(week_52_high, 2),
            '52_week_low': round(week_52_low, 2),
            'position_value': round(current_price * quantity, 2),
            'data': data  # Store for backtesting
        }

# Initialize strategy
strategy = IndianStockStrategy(portfolio_capital=10000)